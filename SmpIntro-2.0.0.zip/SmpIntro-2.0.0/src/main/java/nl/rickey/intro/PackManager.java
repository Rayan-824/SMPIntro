package nl.rickey.intro;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Regelt de resource pack met de muziek: URL, SHA-1, versturen naar spelers en een diagnose
 * (/intro pack test) die precies zegt waarom een download niet werkt.
 */
final class PackManager {

    static final String FILE_NAME = "SmpIntroPack.zip";
    private static final Set<String> FINAL_STATUSES = Set.of(
            "SUCCESSFULLY_LOADED", "DECLINED", "FAILED_DOWNLOAD", "INVALID_URL", "FAILED_RELOAD", "DISCARDED");
    private static final int MAX_BYTES = 80 * 1024 * 1024;

    private final IntroPlugin plugin;
    private final Map<UUID, String> status = new ConcurrentHashMap<>();
    private final File packFile;
    private volatile String sha1;
    private volatile boolean hashPending;
    private HttpServer server;

    PackManager(IntroPlugin plugin) {
        this.plugin = plugin;
        this.packFile = new File(plugin.getDataFolder(), FILE_NAME);
    }

    // ------------------------------------------------------------ levenscyclus

    void start() {
        extractPack();
        startServer();
        refresh();
    }

    void reload() {
        stopServer();
        startServer();
        refresh();
    }

    void stop() {
        stopServer();
    }

    /** Zet de meegeleverde pack in de pluginmap, zodat je hem kunt uploaden of zelf laten hosten. */
    private void extractPack() {
        try {
            if (!packFile.exists()) {
                plugin.getDataFolder().mkdirs();
                try (InputStream in = plugin.getResource(FILE_NAME)) {
                    if (in != null) Files.copy(in, packFile.toPath());
                }
            }
        } catch (IOException ex) {
            plugin.getLogger().warning("Kon " + FILE_NAME + " niet uitpakken: " + ex.getMessage());
        }
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    boolean enabled() {
        return cfg().getBoolean("pack.enabled", true);
    }

    boolean required() {
        return cfg().getBoolean("pack.required", false);
    }

    /** De URL die spelers gebruiken: eigen URL, anders de ingebouwde server. */
    String url() {
        String own = cfg().getString("pack.url", "").trim();
        if (!own.isEmpty()) return own;
        if (cfg().getBoolean("pack.server.enabled", false)) {
            String address = cfg().getString("pack.server.address", "").trim();
            if (!address.isEmpty()) {
                return "http://" + address + ":" + cfg().getInt("pack.server.port", 8123) + "/" + FILE_NAME;
            }
        }
        return "";
    }

    /** Klaar om te versturen: aan, URL bekend en SHA-1 bekend. */
    boolean isReady() {
        return enabled() && !url().isEmpty() && sha1 != null;
    }

    boolean isConfigured() {
        return enabled() && !url().isEmpty();
    }

    /** Zoekt de SHA-1 uit de config of rekent hem uit (lokaal bestand of download van de URL). */
    private void refresh() {
        sha1 = null;
        hashPending = false;
        if (!enabled()) return;
        String configured = cfg().getString("pack.sha1", "").trim().toLowerCase(Locale.ROOT);
        if (configured.matches("[0-9a-f]{40}")) {
            sha1 = configured;
            return;
        }
        String url = url();
        if (url.isEmpty()) {
            plugin.getLogger().warning("Geen pack-url ingesteld: de intro draait zonder muziek. "
                    + "Zie pack.url (of pack.server) in config.yml en gebruik /intro pack test.");
            return;
        }
        boolean ownServer = cfg().getString("pack.url", "").trim().isEmpty();
        hashPending = true;
        if (ownServer) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    byte[] bytes = Files.readAllBytes(packFile.toPath());
                    sha1 = hex(MessageDigest.getInstance("SHA-1").digest(bytes));
                    plugin.getLogger().info("Resource pack (ingebouwde server) klaar, SHA-1 " + sha1);
                } catch (Exception ex) {
                    plugin.getLogger().warning("Kon de pack niet lezen: " + ex.getMessage());
                } finally {
                    hashPending = false;
                }
            });
        } else {
            inspect(url).thenAccept(r -> {
                if (r.ok()) {
                    sha1 = r.sha1();
                    plugin.getLogger().info("Resource pack bereikbaar (" + r.size() / 1024 + " kB), SHA-1 " + sha1);
                } else {
                    plugin.getLogger().warning("Resource pack niet bruikbaar: " + r.problem());
                }
                hashPending = false;
            });
        }
    }

    // ------------------------------------------------------------ versturen

    /** Stuurt de pack als de speler hem nog niet heeft geladen of nog niet aan het laden is. */
    void ensure(Player player) {
        if (!isReady()) return;
        String s = status.get(player.getUniqueId());
        if (s != null) return; // al verstuurd of al geladen
        send(player);
    }

    void send(Player player) {
        if (!isReady()) return;
        UUID id = UUID.nameUUIDFromBytes(("smpintro-pack:" + sha1).getBytes(StandardCharsets.UTF_8));
        Component prompt = Msg.mm(cfg().getString("pack.prompt", "<gold>Muziek voor de Hardcore SMP 2 intro"));
        status.put(player.getUniqueId(), "SENT");
        player.setResourcePack(id, url(), sha1, prompt, required());
    }

    void onStatus(Player player, String name) {
        status.put(player.getUniqueId(), name);
        String hint = switch (name) {
            case "FAILED_DOWNLOAD" -> " - de speler kon de pack niet downloaden (URL, hash of bestand klopt niet). Gebruik /intro pack test.";
            case "INVALID_URL" -> " - de URL is ongeldig.";
            case "FAILED_RELOAD" -> " - de pack is gedownload maar het laden mislukte (kapotte zip of pack.mcmeta).";
            case "DECLINED" -> " - de speler heeft de pack geweigerd.";
            default -> "";
        };
        plugin.getLogger().info(player.getName() + " resource pack: " + name + hint);
    }

    void forget(Player player) {
        status.remove(player.getUniqueId());
    }

    boolean isLoaded(Player player) {
        return "SUCCESSFULLY_LOADED".equals(status.get(player.getUniqueId()));
    }

    /** True als er niets meer te wachten valt: pack uit/niet beschikbaar, of de speler heeft een eindstatus. */
    boolean isSettled(Player player) {
        if (!enabled() || url().isEmpty()) return true;
        if (hashPending) return false;
        if (sha1 == null) return true;
        String s = status.get(player.getUniqueId());
        return s != null && FINAL_STATUSES.contains(s);
    }

    // ------------------------------------------------------------ diagnose

    record Inspection(boolean ok, int statusCode, String finalUrl, String contentType, int size, String sha1,
                      boolean zip, boolean hasMeta, boolean hasSound, String problem) {
    }

    java.util.concurrent.CompletableFuture<Inspection> inspect(String url) {
        return java.util.concurrent.CompletableFuture.supplyAsync(() -> {
            try {
                HttpClient client = HttpClient.newBuilder()
                        .followRedirects(HttpClient.Redirect.NORMAL)
                        .connectTimeout(Duration.ofSeconds(15))
                        .build();
                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(60))
                        .header("User-Agent", "SmpIntro/2.0")
                        .GET().build();
                HttpResponse<InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
                int code = response.statusCode();
                String type = response.headers().firstValue("content-type").orElse("onbekend");
                String finalUrl = response.uri().toString();
                byte[] bytes;
                try (InputStream in = response.body()) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        if (out.size() > MAX_BYTES) {
                            return new Inspection(false, code, finalUrl, type, out.size(), null, false, false, false,
                                    "bestand is groter dan 80 MB");
                        }
                    }
                    bytes = out.toByteArray();
                }
                if (code != 200) {
                    String why = code == 404 ? "bestand niet gevonden (404): controleer de link"
                            : code == 403 ? "toegang geweigerd (403): is de repository publiek?"
                            : "de server antwoordde met status " + code;
                    return new Inspection(false, code, finalUrl, type, bytes.length, null, false, false, false, why);
                }
                boolean zip = bytes.length > 4 && bytes[0] == 'P' && bytes[1] == 'K';
                if (!zip) {
                    String why = type.toLowerCase(Locale.ROOT).contains("html")
                            ? "dit is een webpagina, geen directe download (bij GitHub: gebruik de raw-link of een release-link, geen /blob/-link; bij Dropbox ?dl=1)"
                            : "dit is geen zip-bestand";
                    return new Inspection(false, code, finalUrl, type, bytes.length, null, false, false, false, why);
                }
                boolean meta = false;
                boolean sound = false;
                try (ZipInputStream zin = new ZipInputStream(new java.io.ByteArrayInputStream(bytes))) {
                    ZipEntry entry;
                    while ((entry = zin.getNextEntry()) != null) {
                        String name = entry.getName();
                        if (name.equals("pack.mcmeta")) meta = true;
                        if (name.equals("assets/smpintro/sounds.json")) sound = true;
                    }
                }
                String hash = hex(MessageDigest.getInstance("SHA-1").digest(bytes));
                String problem = null;
                if (!meta) problem = "pack.mcmeta staat niet in de root van de zip (zip de INHOUD van de map, niet de map zelf)";
                else if (!sound) problem = "assets/smpintro/sounds.json ontbreekt: dit is niet de SmpIntro-pack";
                return new Inspection(problem == null, code, finalUrl, type, bytes.length, hash, true, meta, sound, problem);
            } catch (IllegalArgumentException ex) {
                return new Inspection(false, 0, url, "-", 0, null, false, false, false, "ongeldige URL");
            } catch (Exception ex) {
                String msg = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                return new Inspection(false, 0, url, "-", 0, null, false, false, false,
                        "kan de URL niet bereiken vanaf de server (" + msg + ")");
            }
        });
    }

    /** /intro pack test: laat zien of de URL werkt en welke SHA-1 erbij hoort. */
    void test(CommandSender sender) {
        String url = url();
        if (!enabled()) {
            Msg.send(sender, "<red>pack.enabled staat uit in config.yml.");
            return;
        }
        if (url.isEmpty()) {
            Msg.send(sender, "<red>Er is geen pack-url ingesteld. <gray>Zet <white>pack.url</white> in config.yml "
                    + "(of gebruik <white>pack.server</white>) en doe <white>/intro reload</white>.");
            return;
        }
        Msg.send(sender, "<gray>Pack testen: <white>" + Msg.esc(url));
        inspect(url).thenAccept(r -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (r.statusCode() > 0) {
                Msg.send(sender, "<gray>Status <white>" + r.statusCode() + "</white>, type <white>"
                        + Msg.esc(r.contentType()) + "</white>, grootte <white>" + r.size() / 1024 + " kB");
            }
            if (!r.ok()) {
                Msg.send(sender, "<red>✘ " + Msg.esc(r.problem()));
                return;
            }
            Msg.send(sender, "<green>✔ De pack is bereikbaar en bevat pack.mcmeta en de muziek.");
            String configured = cfg().getString("pack.sha1", "").trim().toLowerCase(Locale.ROOT);
            if (configured.isEmpty()) {
                Msg.send(sender, "<gray>SHA-1: <white>" + r.sha1() + " <gray>(wordt automatisch gebruikt)");
                sha1 = r.sha1();
                hashPending = false;
            } else if (configured.equals(r.sha1())) {
                Msg.send(sender, "<green>✔ pack.sha1 in de config klopt.");
            } else {
                Msg.send(sender, "<red>✘ pack.sha1 in de config klopt NIET. <gray>Juist is: <white>" + r.sha1()
                        + " <gray>(of maak pack.sha1 leeg).");
            }
        }));
    }

    // ------------------------------------------------------------ ingebouwde server

    private void startServer() {
        if (!cfg().getBoolean("pack.server.enabled", false)) return;
        int port = cfg().getInt("pack.server.port", 8123);
        try {
            HttpServer s = HttpServer.create(new InetSocketAddress(port), 0);
            s.createContext("/", this::serve);
            s.setExecutor(Executors.newFixedThreadPool(2));
            s.start();
            server = s;
            plugin.getLogger().info("Pack-server luistert op poort " + port
                    + " (zorg dat die poort bij je host is opengezet).");
        } catch (Throwable t) {
            plugin.getLogger().warning("Kon de pack-server niet starten op poort " + port + ": " + t);
        }
    }

    private void stopServer() {
        if (server != null) {
            server.stop(0);
            server = null;
        }
    }

    private void serve(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            if (!path.equals("/" + FILE_NAME) || !packFile.exists()) {
                ex.sendResponseHeaders(404, -1);
                return;
            }
            long length = packFile.length();
            ex.getResponseHeaders().add("Content-Type", "application/zip");
            if ("HEAD".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.getResponseHeaders().add("Content-Length", String.valueOf(length));
                ex.sendResponseHeaders(200, -1);
                return;
            }
            ex.sendResponseHeaders(200, length);
            try (OutputStream out = ex.getResponseBody()) {
                Files.copy(packFile.toPath(), out);
            }
        } finally {
            ex.close();
        }
    }

    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}

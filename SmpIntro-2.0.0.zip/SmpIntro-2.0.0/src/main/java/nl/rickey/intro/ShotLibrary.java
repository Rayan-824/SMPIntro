package nl.rickey.intro;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Zoekt shots op: eerst je eigen opnames (shots.yml), daarna de automatische shots uit config.yml. */
final class ShotLibrary {

    private final IntroPlugin plugin;
    private final File file;
    private YamlConfiguration data = new YamlConfiguration();

    ShotLibrary(IntroPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shots.yml");
        reload();
    }

    void reload() {
        data = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
    }

    /** Naam van een shot: kleine letters, cijfers, - en _ (maximaal 24 tekens), anders null. */
    static String cleanId(String raw) {
        if (raw == null) return null;
        String id = raw.trim().toLowerCase(Locale.ROOT);
        return id.matches("[a-z0-9_-]{1,24}") ? id : null;
    }

    ShotDef find(String rawId) {
        String id = cleanId(rawId);
        if (id == null) return null;

        ConfigurationSection rec = data.getConfigurationSection("recorded." + id);
        if (rec != null) {
            List<Pose> poses = new ArrayList<>();
            for (String line : rec.getStringList("keys")) {
                Pose p = parsePose(line);
                if (p != null) poses.add(p);
            }
            if (poses.size() < 2) return null;
            return new RecordedShot(id, resolveWorld(rec.getString("world")), poses, rec.getDouble("ease", 0.1));
        }

        ConfigurationSection c = plugin.getConfig().getConfigurationSection("shots." + id);
        if (c == null) return null;
        String type = c.getString("type", "orbit").toLowerCase(Locale.ROOT);
        World world = resolveWorld(c.getString("world", "overworld"));
        return switch (type) {
            case "orbit" -> OrbitShot.from(id, world, c);
            case "flyover" -> FlyoverShot.from(id, world, c);
            default -> null;
        };
    }

    boolean isRecorded(String id) {
        return data.isConfigurationSection("recorded." + id);
    }

    List<String> recordedIds() {
        ConfigurationSection s = data.getConfigurationSection("recorded");
        return s == null ? new ArrayList<>() : new ArrayList<>(s.getKeys(false));
    }

    List<String> configuredIds() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("shots");
        return s == null ? new ArrayList<>() : new ArrayList<>(s.getKeys(false));
    }

    boolean saveRecorded(String id, String worldName, List<Pose> poses, double ease) {
        List<String> lines = new ArrayList<>(poses.size());
        for (Pose p : poses) {
            lines.add(String.format(Locale.ROOT, "%.2f,%.2f,%.2f,%.2f,%.2f", p.x(), p.y(), p.z(), p.yaw(), p.pitch()));
        }
        data.set("recorded." + id + ".world", worldName);
        data.set("recorded." + id + ".ease", ease);
        data.set("recorded." + id + ".keys", lines);
        return write();
    }

    boolean delete(String id) {
        if (!isRecorded(id)) return false;
        data.set("recorded." + id, null);
        return write();
    }

    private boolean write() {
        try {
            plugin.getDataFolder().mkdirs();
            data.save(file);
            return true;
        } catch (IOException ex) {
            plugin.getLogger().warning("Kon shots.yml niet opslaan: " + ex.getMessage());
            return false;
        }
    }

    private static Pose parsePose(String line) {
        try {
            String[] p = line.split(",");
            if (p.length < 5) return null;
            return new Pose(Double.parseDouble(p[0].trim()), Double.parseDouble(p[1].trim()),
                    Double.parseDouble(p[2].trim()), Float.parseFloat(p[3].trim()), Float.parseFloat(p[4].trim()));
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    /** overworld, nether en end zoeken de bijbehorende wereld; andere namen zijn de exacte wereldnaam. */
    static World resolveWorld(String key) {
        if (key == null || key.isBlank()) return null;
        String k = key.trim().toLowerCase(Locale.ROOT);
        World.Environment env = switch (k) {
            case "overworld", "normal" -> World.Environment.NORMAL;
            case "nether", "the_nether" -> World.Environment.NETHER;
            case "end", "the_end" -> World.Environment.THE_END;
            default -> null;
        };
        if (env == null) return Bukkit.getWorld(key.trim());
        for (World w : Bukkit.getWorlds()) {
            if (w.getEnvironment() == env) return w;
        }
        return null;
    }

    /** "spawn" of twee getallen ("0 0"); geeft x en z terug. */
    static double[] center(String raw, World world) {
        if (raw != null && !raw.isBlank() && !raw.trim().equalsIgnoreCase("spawn")) {
            String[] parts = raw.trim().split("[ ,;]+");
            if (parts.length >= 2) {
                try {
                    return new double[]{Double.parseDouble(parts[0]), Double.parseDouble(parts[1])};
                } catch (NumberFormatException ignored) {
                    // val terug op de spawn
                }
            }
        }
        Location spawn = world.getSpawnLocation();
        return new double[]{spawn.getX(), spawn.getZ()};
    }
}

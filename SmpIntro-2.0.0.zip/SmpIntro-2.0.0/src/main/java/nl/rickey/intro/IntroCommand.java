package nl.rickey.intro;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** /intro: afspelen, shots opnemen, voorbereiden en de resource pack testen. */
final class IntroCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = List.of(
            "play", "skip", "stop", "preview", "rec", "shots", "delete", "prepare", "pack", "reset", "reload", "help");

    private final IntroPlugin plugin;
    private ChunkPreloader.Job prepareJob;
    private BukkitTask prepareTask;

    IntroCommand(IntroPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        if (!sub.equals("skip") && !sender.hasPermission("smpintro.admin")) {
            Msg.send(sender, "<red>Dat mag alleen een beheerder.");
            return true;
        }
        switch (sub) {
            case "play" -> play(sender, args);
            case "skip" -> skip(sender, args);
            case "stop" -> stop(sender, args);
            case "preview" -> preview(sender, args);
            case "rec" -> rec(sender, args);
            case "shots" -> shots(sender);
            case "delete" -> delete(sender, args);
            case "prepare" -> prepare(sender);
            case "pack" -> pack(sender, args);
            case "reset" -> reset(sender, args);
            case "reload" -> {
                plugin.reload();
                Msg.send(sender, "<green>Config, shots en pack zijn herladen.");
            }
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender s) {
        Msg.send(s, "<gradient:#f6d365:#fda085><bold>SmpIntro</bold></gradient> <gray>commando's:");
        s.sendMessage(Msg.mm(" <yellow>/intro play [speler|all]</yellow> <dark_gray>»</dark_gray> <gray>Intro afspelen"));
        s.sendMessage(Msg.mm(" <yellow>/intro skip</yellow> <dark_gray>»</dark_gray> <gray>Intro overslaan (of sneak)"));
        s.sendMessage(Msg.mm(" <yellow>/intro stop [speler|all]</yellow> <dark_gray>»</dark_gray> <gray>Intro stoppen"));
        s.sendMessage(Msg.mm(" <yellow>/intro preview <shot> [seconden]</yellow> <dark_gray>»</dark_gray> <gray>Eén shot bekijken"));
        s.sendMessage(Msg.mm(" <yellow>/intro rec <naam></yellow> <dark_gray>»</dark_gray> <gray>Je vlucht opnemen als shot; stop met <white>/intro rec stop"));
        s.sendMessage(Msg.mm(" <yellow>/intro shots</yellow> <dark_gray>»</dark_gray> <gray>Alle shots en de volgorde"));
        s.sendMessage(Msg.mm(" <yellow>/intro delete <naam></yellow> <dark_gray>»</dark_gray> <gray>Opgenomen shot verwijderen"));
        s.sendMessage(Msg.mm(" <yellow>/intro prepare</yellow> <dark_gray>»</dark_gray> <gray>Chunks vooraf genereren"));
        s.sendMessage(Msg.mm(" <yellow>/intro pack [test|send <speler>]</yellow> <dark_gray>»</dark_gray> <gray>Resource pack testen/sturen"));
        s.sendMessage(Msg.mm(" <yellow>/intro reset <speler|all></yellow> <dark_gray>»</dark_gray> <gray>Opnieuw automatisch laten afspelen"));
        s.sendMessage(Msg.mm(" <yellow>/intro reload</yellow> <dark_gray>»</dark_gray> <gray>Config herladen"));
    }

    // ------------------------------------------------------------ afspelen

    private List<Player> targets(CommandSender sender, String arg) {
        List<Player> out = new ArrayList<>();
        if (arg == null) {
            if (sender instanceof Player p) out.add(p);
            return out;
        }
        if (arg.equalsIgnoreCase("all")) {
            out.addAll(Bukkit.getOnlinePlayers());
            return out;
        }
        Player p = Bukkit.getPlayerExact(arg);
        if (p != null) out.add(p);
        return out;
    }

    private void play(CommandSender sender, String[] args) {
        List<Player> list = targets(sender, args.length > 1 ? args[1] : null);
        if (list.isEmpty()) {
            Msg.send(sender, "<red>Geen speler gevonden. <gray>Gebruik <white>/intro play <speler|all></white>.");
            return;
        }
        List<SequenceEntry> sequence = plugin.intro().defaultSequence();
        if (sequence.isEmpty()) {
            Msg.send(sender, "<red>De lijst <white>sequence</white> in config.yml is leeg.");
            return;
        }
        int started = 0;
        for (Player p : list) {
            if (plugin.intro().start(p, sequence, true) != null) started++;
        }
        Msg.send(sender, "<green>Intro gestart voor " + started + " speler(s). <gray>Hij begint zodra alles is geladen.");
    }

    private void skip(CommandSender sender, String[] args) {
        if (args.length > 1 && sender.hasPermission("smpintro.admin")) {
            for (Player p : targets(sender, args[1])) plugin.intro().skip(p);
            return;
        }
        if (sender instanceof Player p && plugin.intro().isActive(p)) {
            plugin.intro().skip(p);
        } else {
            Msg.send(sender, "<gray>Er draait geen intro voor jou.");
        }
    }

    private void stop(CommandSender sender, String[] args) {
        if (args.length > 1 && args[1].equalsIgnoreCase("all")) {
            plugin.intro().stopAll();
            Msg.send(sender, "<green>Alle intro's zijn gestopt.");
            return;
        }
        List<Player> list = targets(sender, args.length > 1 ? args[1] : null);
        for (Player p : list) plugin.intro().skip(p);
        Msg.send(sender, "<green>Gestopt voor " + list.size() + " speler(s).");
    }

    private void preview(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            Msg.send(sender, "<red>Dit kan alleen een speler.");
            return;
        }
        if (args.length < 2) {
            Msg.send(sender, "<red>Gebruik <white>/intro preview <shot> [seconden]");
            return;
        }
        String id = ShotLibrary.cleanId(args[1]);
        if (id == null || plugin.shots().find(id) == null) {
            Msg.send(sender, "<red>Onbekende shot. <gray>Zie <white>/intro shots</white>.");
            return;
        }
        double seconds = 20;
        if (args.length > 2) {
            try {
                seconds = Math.max(3, Math.min(120, Double.parseDouble(args[2])));
            } catch (NumberFormatException ex) {
                Msg.send(sender, "<red>Seconden moet een getal zijn.");
                return;
            }
        }
        SequenceEntry entry = new SequenceEntry(id, seconds, null, null, null);
        if (plugin.intro().start(player, List.of(entry), false) == null) {
            Msg.send(sender, "<red>Er draait al een intro voor jou.");
        }
    }

    // ------------------------------------------------------------ opnemen

    private void rec(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            Msg.send(sender, "<red>Dit kan alleen een speler.");
            return;
        }
        if (args.length < 2) {
            Msg.send(sender, "<gray>Opnemen: <white>/intro rec <naam></white> starten, daarna zelf rustig rondvliegen "
                    + "(creative of spectator), en <white>/intro rec stop</white> om te bewaren.");
            return;
        }
        String arg = args[1].toLowerCase(Locale.ROOT);
        if (arg.equals("stop") || arg.equals("cancel")) {
            int result = plugin.recorder().finish(player, arg.equals("stop"));
            if (result == -1) Msg.send(sender, "<red>Je neemt niets op.");
            else if (arg.equals("cancel")) Msg.send(sender, "<yellow>Opname weggegooid.");
            else if (result == -2) Msg.send(sender, "<red>Die opname was te kort. <gray>Vlieg een stuk langer en probeer opnieuw.");
            else Msg.send(sender, "<green>Opname bewaard met " + result + " punten. <gray>Bekijk hem met <white>/intro preview "
                        + "<naam></white> en pas de lengte aan in <white>sequence</white> in config.yml.");
            return;
        }
        String id = ShotLibrary.cleanId(arg);
        if (id == null) {
            Msg.send(sender, "<red>Een naam bestaat uit kleine letters, cijfers, - en _ (maximaal 24 tekens).");
            return;
        }
        if (plugin.intro().isActive(player)) {
            Msg.send(sender, "<red>Wacht tot je intro klaar is.");
            return;
        }
        if (!plugin.recorder().start(player, id)) {
            Msg.send(sender, "<red>Je neemt al iets op. <gray>Stop met <white>/intro rec stop</white>.");
            return;
        }
        String note = plugin.shots().isRecorded(id) ? " <yellow>(overschrijft de bestaande opname)" : "";
        Msg.send(sender, "<green>Opname <white>" + Msg.esc(id) + "</white> gestart" + note + ". <gray>Vlieg rustig je route; "
                + "stop met <white>/intro rec stop</white>. Een shot met dezelfde naam in <white>sequence</white> gebruikt je opname.");
    }

    private void shots(CommandSender sender) {
        Msg.send(sender, "<gray>Volgorde (sequence) en status:");
        double t = 0;
        Set<String> used = new HashSet<>();
        for (SequenceEntry e : plugin.intro().defaultSequence()) {
            used.add(e.shot());
            ShotDef def = plugin.shots().find(e.shot());
            String status;
            if (def == null) status = "<red>bestaat niet";
            else if (def.world() == null) status = "<red>wereld ontbreekt";
            else status = (plugin.shots().isRecorded(e.shot()) ? "<aqua>opname" : "<green>automatisch")
                    + " <dark_gray>· <gray>" + Msg.esc(def.world().getName()) + " · " + Msg.esc(def.describe());
            Msg.send(sender, "<white>" + (int) t + "s</white> <dark_gray>·</dark_gray> <yellow>" + Msg.esc(e.shot())
                    + "</yellow> <dark_gray>(" + (int) e.seconds() + "s)</dark_gray> " + status);
            t += e.seconds();
        }
        Msg.send(sender, "<gray>Totaal: <white>" + (int) t + " seconden</white>. Muziek duurt ongeveer 177 seconden.");
        List<String> other = new ArrayList<>();
        for (String id : plugin.shots().recordedIds()) if (!used.contains(id)) other.add(id);
        for (String id : plugin.shots().configuredIds()) if (!used.contains(id) && !other.contains(id)) other.add(id);
        if (!other.isEmpty()) {
            Msg.send(sender, "<gray>Niet in de volgorde: <white>" + Msg.esc(String.join(", ", other)));
        }
    }

    private void delete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            Msg.send(sender, "<red>Gebruik <white>/intro delete <naam>");
            return;
        }
        String id = ShotLibrary.cleanId(args[1]);
        if (id != null && plugin.shots().delete(id)) {
            Msg.send(sender, "<green>Opname <white>" + Msg.esc(id) + "</white> is verwijderd.");
        } else {
            Msg.send(sender, "<red>Geen opname met die naam. <gray>(Automatische shots uit config.yml verwijder je daar.)");
        }
    }

    // ------------------------------------------------------------ voorbereiden

    private void prepare(CommandSender sender) {
        if (prepareJob != null) {
            Msg.send(sender, "<yellow>Er loopt al een voorbereiding (" + Math.round(prepareJob.progress() * 100) + "%).");
            return;
        }
        int margin = Math.max(1, plugin.getConfig().getInt("prepare.margin-chunks", 3));
        Map<World, Set<Long>> chunks = new HashMap<>();
        for (SequenceEntry e : plugin.intro().defaultSequence()) {
            ShotDef def = plugin.shots().find(e.shot());
            if (def == null || def.world() == null) continue;
            chunks.computeIfAbsent(def.world(), w -> new HashSet<>()).addAll(def.chunks(margin));
        }
        int total = 0;
        for (Set<Long> s : chunks.values()) total += s.size();
        if (total == 0) {
            Msg.send(sender, "<red>Geen enkele shot heeft een wereld om te laden.");
            return;
        }
        Msg.send(sender, "<green>Voorbereiding gestart: <white>" + total + " chunks</white> laden/genereren. "
                + "<gray>Dit kan een minuut duren; je krijgt een melding als het klaar is.");
        prepareJob = plugin.preloader().load(chunks);
        final ChunkPreloader.Job job = prepareJob;
        prepareTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (job.isDone()) {
                plugin.preloader().release(job);
                prepareJob = null;
                if (prepareTask != null) prepareTask.cancel();
                Msg.send(sender, "<green>Klaar: alle chunks voor de intro zijn gegenereerd.");
            } else {
                Msg.send(sender, "<gray>Voorbereiden… <white>" + Math.round(job.progress() * 100) + "%");
            }
        }, 100L, 100L);
    }

    // ------------------------------------------------------------ pack en reset

    private void pack(CommandSender sender, String[] args) {
        String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "test";
        switch (action) {
            case "send" -> {
                List<Player> list = targets(sender, args.length > 2 ? args[2] : null);
                if (list.isEmpty()) {
                    Msg.send(sender, "<red>Geen speler gevonden.");
                    return;
                }
                if (!plugin.packs().isReady()) {
                    Msg.send(sender, "<red>De pack is nog niet klaar. <gray>Gebruik eerst <white>/intro pack test</white>.");
                    return;
                }
                for (Player p : list) plugin.packs().send(p);
                Msg.send(sender, "<green>Pack gestuurd naar " + list.size() + " speler(s).");
            }
            default -> plugin.packs().test(sender);
        }
    }

    private void reset(CommandSender sender, String[] args) {
        if (args.length < 2) {
            Msg.send(sender, "<red>Gebruik <white>/intro reset <speler|all>");
            return;
        }
        if (args[1].equalsIgnoreCase("all")) {
            plugin.intro().resetAllSeen();
            Msg.send(sender, "<green>Iedereen krijgt de intro opnieuw bij de volgende join.");
            return;
        }
        Player p = Bukkit.getPlayerExact(args[1]);
        if (p == null) {
            Msg.send(sender, "<red>Speler niet online.");
            return;
        }
        plugin.intro().resetSeen(p.getUniqueId());
        Msg.send(sender, "<green>" + Msg.esc(p.getName()) + " krijgt de intro opnieuw bij de volgende join.");
    }

    // ------------------------------------------------------------ tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBS) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            return out;
        }
        if (args.length == 2) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "play", "stop", "skip", "reset" -> {
                    out.add("all");
                    for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
                }
                case "preview", "delete", "rec" -> {
                    out.addAll(plugin.shots().recordedIds());
                    out.addAll(plugin.shots().configuredIds());
                    if (args[0].equalsIgnoreCase("rec")) {
                        out.add("stop");
                        out.add("cancel");
                    }
                }
                case "pack" -> {
                    out.add("test");
                    out.add("send");
                }
                default -> {
                }
            }
            out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(prefix));
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("pack") && args[1].equalsIgnoreCase("send")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT)));
        }
        return out;
    }
}

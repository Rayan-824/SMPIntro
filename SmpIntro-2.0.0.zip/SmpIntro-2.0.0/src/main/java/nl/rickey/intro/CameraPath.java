package nl.rickey.intro;

/** Een camerabeweging: u loopt van 0 (begin) tot 1 (einde) en geeft de pose op dat moment. */
interface CameraPath {
    Pose at(double u);
}

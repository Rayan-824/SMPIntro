package nl.rickey.intro;

import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Set;

/** Hoogtes, chunk-sleutels en een controle of de camera niet in blokken zit. */
final class Terrain {

    private Terrain() {
    }

    /** Hoogste blok (inclusief bladeren en water) op deze kolom. De chunk moet bij voorkeur al geladen zijn. */
    static int ground(World world, double x, double z) {
        return world.getHighestBlockYAt((int) Math.floor(x), (int) Math.floor(z), HeightMap.MOTION_BLOCKING);
    }

    static long key(int chunkX, int chunkZ) {
        return ((long) chunkX << 32) | (chunkZ & 0xFFFFFFFFL);
    }

    static int keyX(long key) {
        return (int) (key >> 32);
    }

    static int keyZ(long key) {
        return (int) key;
    }

    /** Alle chunks rondom een blokpositie, binnen een ronde marge (in chunks). */
    static void addAround(Set<Long> out, double x, double z, int margin) {
        int cx = Math.floorDiv((int) Math.floor(x), 16);
        int cz = Math.floorDiv((int) Math.floor(z), 16);
        double limit = (margin + 0.5) * (margin + 0.5);
        for (int dx = -margin; dx <= margin; dx++) {
            for (int dz = -margin; dz <= margin; dz++) {
                if (dx * dx + dz * dz <= limit) out.add(key(cx + dx, cz + dz));
            }
        }
    }

    /** Alle chunks binnen een cirkel met deze straal (in blokken). */
    static void addDisk(Set<Long> out, double centerX, double centerZ, double radius) {
        int minX = Math.floorDiv((int) Math.floor(centerX - radius), 16);
        int maxX = Math.floorDiv((int) Math.floor(centerX + radius), 16);
        int minZ = Math.floorDiv((int) Math.floor(centerZ - radius), 16);
        int maxZ = Math.floorDiv((int) Math.floor(centerZ + radius), 16);
        for (int cx = minX; cx <= maxX; cx++) {
            for (int cz = minZ; cz <= maxZ; cz++) {
                double nearestX = Math.max(cx * 16.0, Math.min(centerX, cx * 16.0 + 16));
                double nearestZ = Math.max(cz * 16.0, Math.min(centerZ, cz * 16.0 + 16));
                double dx = nearestX - centerX;
                double dz = nearestZ - centerZ;
                if (dx * dx + dz * dz <= radius * radius) out.add(key(cx, cz));
            }
        }
    }

    /**
     * Controleert langs het pad of de camera niet in vaste blokken zit.
     *
     * @return null als het pad schoon is, anders een omschrijving van het probleem
     */
    static String checkClear(World world, CameraPath path, int samples) {
        if (world == null) return "wereld bestaat niet";
        int blocked = 0;
        for (int i = 0; i <= samples; i++) {
            Pose p = path.at(i / (double) samples);
            if (Double.isNaN(p.x()) || Double.isNaN(p.y()) || Double.isNaN(p.z())) return "ongeldig pad";
            if (p.y() < world.getMinHeight() + 2 || p.y() > world.getMaxHeight() - 2) return "camera buiten de wereld";
            Location at = new Location(world, p.x(), p.y(), p.z());
            if (!at.getBlock().isPassable()) blocked++;
        }
        double share = blocked / (double) (samples + 1);
        if (share > 0.06) {
            return "camera zit " + Math.round(share * 100) + "% van de tijd in vaste blokken";
        }
        return null;
    }
}

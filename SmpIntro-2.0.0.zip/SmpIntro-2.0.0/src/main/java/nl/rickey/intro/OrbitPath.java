package nl.rickey.intro;

/** Cirkelvlucht rond een punt; de camera kijkt steeds naar het middelpunt. */
final class OrbitPath implements CameraPath {

    private final double cx;
    private final double cz;
    private final double lookY;
    private final double r0;
    private final double r1;
    private final double y0;
    private final double y1;
    private final double startDeg;
    private final double sweepDeg;
    private final double ease;

    OrbitPath(double cx, double cz, double lookY, double r0, double r1, double y0, double y1,
              double startDeg, double sweepDeg, double ease) {
        this.cx = cx;
        this.cz = cz;
        this.lookY = lookY;
        this.r0 = r0;
        this.r1 = r1;
        this.y0 = y0;
        this.y1 = y1;
        this.startDeg = startDeg;
        this.sweepDeg = sweepDeg;
        this.ease = ease;
    }

    @Override
    public Pose at(double u) {
        double s = Ease.trapezoid(u, ease);
        double angle = Math.toRadians(startDeg + sweepDeg * s);
        double r = Ease.lerp(r0, r1, s);
        double y = Ease.lerp(y0, y1, s);
        return Pose.lookAt(cx + r * Math.cos(angle), y, cz + r * Math.sin(angle), cx, lookY, cz);
    }
}

package nl.rickey.intro;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import java.util.UUID;

/** Koppelt de intro aan join/quit, sneak (overslaan) en de status van de resource pack. */
final class IntroListener implements Listener {

    private final IntroPlugin plugin;

    IntroListener(IntroPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        plugin.intro().restorePending(player);

        long delay = Math.max(1, plugin.getConfig().getLong("auto-play.delay-ticks", 80));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || plugin.intro().isActive(p)) return;

            boolean auto = plugin.getConfig().getBoolean("auto-play.enabled", true);
            boolean everyJoin = plugin.getConfig().getBoolean("auto-play.every-join", false);
            boolean due = auto && (everyJoin || !plugin.intro().hasSeen(id));
            if (due && !p.isDead() && p.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                plugin.intro().start(p, plugin.intro().defaultSequence(), true);
            } else if (plugin.getConfig().getBoolean("pack.send-on-join", true)) {
                plugin.packs().ensure(p);
            }
        }, delay);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.intro().quit(player);
        plugin.recorder().finish(player, true);
        plugin.packs().forget(player);
    }

    /** Sneak (shift) slaat de intro over. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSneak(PlayerToggleSneakEvent event) {
        if (event.isSneaking() && plugin.intro().isActive(event.getPlayer())) {
            plugin.intro().skip(event.getPlayer());
        }
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent event) {
        plugin.packs().onStatus(event.getPlayer(), event.getStatus().name());
    }

    /** Tijdens de intro kan een speler nergens last van hebben. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player && plugin.intro().isActive(player)) {
            event.setCancelled(true);
        }
    }
}

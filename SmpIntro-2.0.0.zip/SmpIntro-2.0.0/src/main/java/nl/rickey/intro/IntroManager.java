package nl.rickey.intro;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Houdt bij wie de intro draait, wie hem al gezien heeft en wie na een crash hersteld moet worden. */
final class IntroManager {

    private final IntroPlugin plugin;
    private final Map<UUID, IntroSession> sessions = new HashMap<>();
    private final Set<UUID> seen = new HashSet<>();
    private final File seenFile;
    private final File restoreFile;
    private final YamlConfiguration restore;

    IntroManager(IntroPlugin plugin) {
        this.plugin = plugin;
        this.seenFile = new File(plugin.getDataFolder(), "seen.yml");
        this.restoreFile = new File(plugin.getDataFolder(), "restore.yml");
        this.restore = restoreFile.exists() ? YamlConfiguration.loadConfiguration(restoreFile) : new YamlConfiguration();
        if (seenFile.exists()) {
            for (String id : YamlConfiguration.loadConfiguration(seenFile).getStringList("seen")) {
                try {
                    seen.add(UUID.fromString(id));
                } catch (IllegalArgumentException ignored) {
                    // kapotte regel overslaan
                }
            }
        }
    }

    // ------------------------------------------------------------ sessies

    boolean isActive(Player player) {
        return sessions.containsKey(player.getUniqueId());
    }

    IntroSession session(Player player) {
        return sessions.get(player.getUniqueId());
    }

    int activeCount() {
        return sessions.size();
    }

    /** Start een intro voor deze speler; null als er al een draait. */
    IntroSession start(Player player, List<SequenceEntry> sequence, boolean full) {
        if (sessions.containsKey(player.getUniqueId())) return null;
        IntroSession session = new IntroSession(plugin, this, player, sequence, full);
        sessions.put(player.getUniqueId(), session);
        session.begin();
        return session;
    }

    void skip(Player player) {
        IntroSession s = sessions.get(player.getUniqueId());
        if (s != null) s.end(IntroSession.End.SKIPPED);
    }

    void quit(Player player) {
        IntroSession s = sessions.get(player.getUniqueId());
        if (s != null) s.end(IntroSession.End.QUIT);
    }

    void stopAll() {
        for (IntroSession s : new ArrayList<>(sessions.values())) s.end(IntroSession.End.SKIPPED);
    }

    void shutdown() {
        for (IntroSession s : new ArrayList<>(sessions.values())) s.end(IntroSession.End.SHUTDOWN);
        sessions.clear();
    }

    /** Wordt door de sessie aangeroepen als hij klaar is. */
    void finished(IntroSession session, boolean markSeen, boolean clearRestore) {
        UUID id = session.player().getUniqueId();
        sessions.remove(id);
        if (clearRestore) {
            restore.set(id.toString(), null);
            saveRestoreFile();
        }
        if (markSeen) {
            seen.add(id);
            saveSeen();
        }
    }

    // ------------------------------------------------------------ gezien

    boolean hasSeen(UUID id) {
        return seen.contains(id);
    }

    void resetSeen(UUID id) {
        seen.remove(id);
        saveSeen();
    }

    void resetAllSeen() {
        seen.clear();
        saveSeen();
    }

    private void saveSeen() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> ids = new ArrayList<>();
        for (UUID id : seen) ids.add(id.toString());
        y.set("seen", ids);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(seenFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Kon seen.yml niet opslaan: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------ herstel na een crash

    void saveRestore(Player player, GameMode mode, Location at) {
        String key = player.getUniqueId().toString();
        if (restore.contains(key) || at.getWorld() == null) return; // bewaar de oudste (echte) positie
        restore.set(key + ".world", at.getWorld().getName());
        restore.set(key + ".x", at.getX());
        restore.set(key + ".y", at.getY());
        restore.set(key + ".z", at.getZ());
        restore.set(key + ".yaw", (double) at.getYaw());
        restore.set(key + ".pitch", (double) at.getPitch());
        restore.set(key + ".mode", mode.name());
        saveRestoreFile();
    }

    /** Zet een speler terug als de server tijdens zijn intro is gestopt of gecrasht. */
    void restorePending(Player player) {
        String key = player.getUniqueId().toString();
        if (!restore.contains(key) || sessions.containsKey(player.getUniqueId())) return;
        World world = Bukkit.getWorld(restore.getString(key + ".world", ""));
        if (world != null) {
            player.teleport(new Location(world, restore.getDouble(key + ".x"), restore.getDouble(key + ".y"),
                    restore.getDouble(key + ".z"), (float) restore.getDouble(key + ".yaw"),
                    (float) restore.getDouble(key + ".pitch")));
        }
        try {
            player.setGameMode(GameMode.valueOf(restore.getString(key + ".mode", "SURVIVAL")));
        } catch (IllegalArgumentException ex) {
            player.setGameMode(GameMode.SURVIVAL);
        }
        player.resetPlayerTime();
        player.resetPlayerWeather();
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        restore.set(key, null);
        saveRestoreFile();
        plugin.getLogger().info(player.getName() + " is hersteld na een onderbroken intro.");
    }

    private void saveRestoreFile() {
        try {
            plugin.getDataFolder().mkdirs();
            restore.save(restoreFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Kon restore.yml niet opslaan: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------ volgorde uit config.yml

    List<SequenceEntry> defaultSequence() {
        List<SequenceEntry> out = new ArrayList<>();
        for (Map<?, ?> m : plugin.getConfig().getMapList("sequence")) {
            Object shot = m.get("shot");
            if (shot == null) continue;
            Object seconds = m.get("seconds");
            Object time = m.get("time");
            Object caption = m.get("caption");
            Object fallback = m.get("fallback");
            out.add(new SequenceEntry(
                    String.valueOf(shot).trim().toLowerCase(Locale.ROOT),
                    seconds instanceof Number ? ((Number) seconds).doubleValue() : 10.0,
                    time instanceof Number ? ((Number) time).longValue() : null,
                    caption == null ? null : String.valueOf(caption),
                    fallback == null ? null : String.valueOf(fallback).trim().toLowerCase(Locale.ROOT)));
        }
        return out;
    }
}

package nl.rickey.intro;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;

/** Kleine hulpklasse voor MiniMessage-berichten. */
final class Msg {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final String PREFIX = "<dark_gray>[<gradient:#f6d365:#fda085><bold>Intro</bold></gradient><dark_gray>] <gray>";

    private Msg() {
    }

    static Component mm(String miniMessage) {
        return MM.deserialize(miniMessage == null ? "" : miniMessage);
    }

    /** Maakt gewone tekst veilig om in een MiniMessage-bericht te zetten. */
    static String esc(String text) {
        return MM.escapeTags(text == null ? "" : text);
    }

    static void send(CommandSender to, String miniMessage) {
        to.sendMessage(mm(PREFIX + miniMessage));
    }
}

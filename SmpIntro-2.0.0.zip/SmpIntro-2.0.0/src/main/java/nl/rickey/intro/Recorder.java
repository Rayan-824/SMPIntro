package nl.rickey.intro;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Neemt een vlucht van een speler op (elke 4 ticks een punt), maakt die glad en bewaart hem als shot.
 * Vlieg rustig rond in creative of spectator: de camera volgt later een vloeiende versie van jouw route.
 */
final class Recorder {

    private static final class Rec {
        final String id;
        final World world;
        final List<Pose> raw = new ArrayList<>();
        BukkitTask task;

        Rec(String id, World world) {
            this.id = id;
            this.world = world;
        }
    }

    private final IntroPlugin plugin;
    private final Map<UUID, Rec> active = new HashMap<>();

    Recorder(IntroPlugin plugin) {
        this.plugin = plugin;
    }

    boolean isRecording(Player player) {
        return active.containsKey(player.getUniqueId());
    }

    boolean start(Player player, String id) {
        if (active.containsKey(player.getUniqueId())) return false;
        Rec rec = new Rec(id, player.getWorld());
        active.put(player.getUniqueId(), rec);
        rec.task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> sample(player, rec), 0L, 4L);
        return true;
    }

    private void sample(Player player, Rec rec) {
        if (!player.isOnline()) {
            finish(player, true);
            return;
        }
        if (!player.getWorld().equals(rec.world)) {
            Msg.send(player, "<yellow>Je bent van wereld gewisseld: de opname is hier gestopt en bewaard.");
            finish(player, true);
            return;
        }
        Location e = player.getEyeLocation();
        rec.raw.add(new Pose(e.getX(), e.getY(), e.getZ(), e.getYaw(), e.getPitch()));
        player.sendActionBar(Msg.mm("<red>● REC <white>" + Msg.esc(rec.id) + " <gray>· " + rec.raw.size()
                + " punten · <white>/intro rec stop"));
    }

    /** Stopt de opname. Bij save=true wordt de route gladgestreken en bewaard; geeft het aantal punten, of -1. */
    int finish(Player player, boolean save) {
        Rec rec = active.remove(player.getUniqueId());
        if (rec == null) return -1;
        if (rec.task != null) rec.task.cancel();
        if (!save) return 0;
        List<Pose> poses = process(rec.raw);
        if (poses == null) return -2;
        plugin.shots().saveRecorded(rec.id, rec.world.getName(), poses, 0.1);
        return poses.size();
    }

    void shutdown() {
        for (UUID id : new ArrayList<>(active.keySet())) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) finish(p, true);
        }
        active.clear();
    }

    /** Dunt de route uit en maakt hem glad met een Gaussisch venster; null als hij te kort is. */
    static List<Pose> process(List<Pose> raw) {
        List<Pose> keep = new ArrayList<>();
        Pose last = null;
        for (Pose p : raw) {
            if (last == null || dist(p, last) >= 1.5
                    || Math.abs(Ease.wrap(p.yaw() - last.yaw())) >= 6 || Math.abs(p.pitch() - last.pitch()) >= 6) {
                keep.add(p);
                last = p;
            }
        }
        if (keep.size() < 3) return null;

        int n = keep.size();
        double[] x = new double[n];
        double[] y = new double[n];
        double[] z = new double[n];
        double[] yaw = new double[n];
        double[] pitch = new double[n];
        for (int i = 0; i < n; i++) {
            Pose p = keep.get(i);
            x[i] = p.x();
            y[i] = p.y();
            z[i] = p.z();
            yaw[i] = p.yaw();
            pitch[i] = p.pitch();
            if (i > 0) {
                while (yaw[i] - yaw[i - 1] > 180) yaw[i] -= 360;
                while (yaw[i] - yaw[i - 1] < -180) yaw[i] += 360;
            }
        }
        double[] sx = smooth(x);
        double[] sy = smooth(y);
        double[] sz = smooth(z);
        double[] syaw = smooth(yaw);
        double[] spitch = smooth(pitch);

        int stride = Math.max(1, (int) Math.ceil(n / 500.0));
        List<Pose> out = new ArrayList<>();
        for (int i = 0; i < n; i += stride) {
            out.add(new Pose(sx[i], sy[i], sz[i], Ease.wrap(syaw[i]), (float) Math.max(-89, Math.min(89, spitch[i]))));
        }
        int lastIndex = n - 1;
        if ((n - 1) % stride != 0) {
            out.add(new Pose(sx[lastIndex], sy[lastIndex], sz[lastIndex], Ease.wrap(syaw[lastIndex]),
                    (float) Math.max(-89, Math.min(89, spitch[lastIndex]))));
        }
        return out;
    }

    private static double dist(Pose a, Pose b) {
        double dx = a.x() - b.x();
        double dy = a.y() - b.y();
        double dz = a.z() - b.z();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Gaussisch gemiddelde (sigma 2 punten) met vastgehouden randen. */
    private static double[] smooth(double[] v) {
        int n = v.length;
        double[] out = new double[n];
        double sigma = 2.0;
        int radius = 5;
        for (int i = 0; i < n; i++) {
            double sum = 0;
            double weight = 0;
            for (int k = -radius; k <= radius; k++) {
                int j = Math.max(0, Math.min(n - 1, i + k));
                double w = Math.exp(-(k * k) / (2 * sigma * sigma));
                sum += v[j] * w;
                weight += w;
            }
            out[i] = sum / weight;
        }
        // Begin en eind precies behouden, zodat de shot begint en eindigt waar jij begon en eindigde
        out[0] = v[0];
        out[n - 1] = v[n - 1];
        return out;
    }
}

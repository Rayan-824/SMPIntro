package nl.rickey.intro;

import org.bukkit.World;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Shot uit een opgenomen vlucht (/intro rec). */
final class RecordedShot implements ShotDef {

    private final String id;
    private final World world;
    private final List<Pose> poses;
    private final double ease;

    RecordedShot(String id, World world, List<Pose> poses, double ease) {
        this.id = id;
        this.world = world;
        this.poses = poses;
        this.ease = ease;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public World world() {
        return world;
    }

    @Override
    public Set<Long> chunks(int margin) {
        Set<Long> out = new HashSet<>();
        if (world == null) return out;
        for (int i = 0; i < poses.size(); i += 3) {
            Pose p = poses.get(i);
            Terrain.addAround(out, p.x(), p.z(), margin);
        }
        Pose last = poses.get(poses.size() - 1);
        Terrain.addAround(out, last.x(), last.z(), margin);
        return out;
    }

    @Override
    public CameraPath build() {
        return new SplinePath(poses, ease);
    }

    /** Een opgenomen route is door jou gevlogen, dus die hoeft niet op blokken gecontroleerd te worden. */
    @Override
    public String check(CameraPath path) {
        return world == null ? "wereld bestaat niet" : null;
    }

    @Override
    public String describe() {
        return "opgenomen route met " + poses.size() + " punten";
    }
}

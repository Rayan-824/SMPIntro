package nl.rickey.intro;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/** Laadt (en genereert) chunks vooraf en houdt ze vast zolang de intro draait. */
final class ChunkPreloader {

    private static final int MAX_INFLIGHT = 10;

    private final IntroPlugin plugin;
    /** Hoeveel jobs een chunk vasthouden: "wereld:x:z" naar aantal. */
    private final Map<String, Integer> held = new HashMap<>();

    ChunkPreloader(IntroPlugin plugin) {
        this.plugin = plugin;
    }

    static final class Request {
        final World world;
        final int x;
        final int z;

        Request(World world, int x, int z) {
            this.world = world;
            this.x = x;
            this.z = z;
        }
    }

    static final class Job {
        private final Queue<Request> queue = new ArrayDeque<>();
        private final List<Request> held = new ArrayList<>();
        private int total;
        private int finished;
        private int inflight;
        private boolean released;
        private BukkitTask task;

        double progress() {
            return total == 0 ? 1.0 : Math.min(1.0, finished / (double) total);
        }

        boolean isDone() {
            return finished >= total;
        }

        int total() {
            return total;
        }
    }

    Job load(Map<World, Set<Long>> chunks) {
        Job job = new Job();
        for (Map.Entry<World, Set<Long>> e : chunks.entrySet()) {
            for (long k : e.getValue()) {
                job.queue.add(new Request(e.getKey(), Terrain.keyX(k), Terrain.keyZ(k)));
            }
        }
        job.total = job.queue.size();
        if (job.total > 0) {
            job.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> pump(job), 1L, 2L);
        }
        return job;
    }

    private void pump(Job job) {
        if (job.released) return;
        while (job.inflight < MAX_INFLIGHT && !job.queue.isEmpty()) {
            Request r = job.queue.poll();
            acquire(r);
            job.held.add(r);
            job.inflight++;
            try {
                r.world.getChunkAtAsync(r.x, r.z, true).whenComplete((chunk, error) ->
                        Bukkit.getScheduler().runTask(plugin, () -> {
                            job.inflight--;
                            job.finished++;
                        }));
            } catch (RuntimeException ex) {
                job.inflight--;
                job.finished++;
            }
        }
        if (job.queue.isEmpty() && job.finished >= job.total && job.task != null) {
            job.task.cancel();
        }
    }

    /** Geeft alle chunks van deze job weer vrij. */
    void release(Job job) {
        if (job == null || job.released) return;
        job.released = true;
        if (job.task != null) job.task.cancel();
        for (Request r : job.held) drop(r);
        job.held.clear();
    }

    void shutdown() {
        for (World w : Bukkit.getWorlds()) {
            w.removePluginChunkTickets(plugin);
        }
        held.clear();
    }

    private static String id(Request r) {
        return r.world.getName() + ":" + r.x + ":" + r.z;
    }

    private void acquire(Request r) {
        int n = held.merge(id(r), 1, Integer::sum);
        if (n == 1) r.world.addPluginChunkTicket(r.x, r.z, plugin);
    }

    private void drop(Request r) {
        String key = id(r);
        Integer n = held.get(key);
        if (n == null) return;
        if (n <= 1) {
            held.remove(key);
            r.world.removePluginChunkTicket(r.x, r.z, plugin);
        } else {
            held.put(key, n - 1);
        }
    }
}

package nl.rickey.intro;

/**
 * Eén stap in de intro: welke shot, hoe lang (seconden), eventueel het uur van de dag voor de speler,
 * een tekst in de actiebalk en een reserve-shot als de eerste niet bruikbaar is.
 */
record SequenceEntry(String shot, double seconds, Long time, String caption, String fallback) {
}

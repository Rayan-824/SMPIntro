package nl.rickey.intro;

import java.util.List;

/**
 * Vloeiende lijn door een rij punten (Catmull-Rom). De camera beweegt met constante snelheid over de lijn,
 * met zacht optrekken en afremmen. Ook de kijkrichting wordt vloeiend geïnterpoleerd.
 */
final class SplinePath implements CameraPath {

    private static final int STEPS = 12;

    private final double[] len;
    private final double[] px;
    private final double[] py;
    private final double[] pz;
    private final double[] yaw;
    private final double[] pitch;
    private final double total;
    private final double ease;

    SplinePath(List<Pose> keys, double ease) {
        this.ease = ease;
        int n = keys.size();
        if (n < 1) throw new IllegalArgumentException("Minstens 1 punt nodig");
        double[] kx = new double[Math.max(n, 2)];
        double[] ky = new double[kx.length];
        double[] kz = new double[kx.length];
        double[] kyaw = new double[kx.length];
        double[] kpitch = new double[kx.length];
        for (int i = 0; i < kx.length; i++) {
            Pose p = keys.get(Math.min(i, n - 1));
            kx[i] = p.x();
            ky[i] = p.y();
            kz[i] = p.z();
            kyaw[i] = p.yaw();
            kpitch[i] = p.pitch();
        }
        n = kx.length;
        // Yaw uitrollen zodat 359 naar 1 geen sprong van 358 graden wordt
        for (int i = 1; i < n; i++) {
            double d = kyaw[i] - kyaw[i - 1];
            while (d > 180) {
                kyaw[i] -= 360;
                d -= 360;
            }
            while (d < -180) {
                kyaw[i] += 360;
                d += 360;
            }
        }

        int count = (n - 1) * STEPS + 1;
        len = new double[count];
        px = new double[count];
        py = new double[count];
        pz = new double[count];
        yaw = new double[count];
        pitch = new double[count];
        int idx = 0;
        for (int i = 0; i < n - 1; i++) {
            int a = Math.max(0, i - 1);
            int b = i;
            int c = i + 1;
            int d = Math.min(n - 1, i + 2);
            for (int s = 0; s < STEPS; s++) {
                double t = s / (double) STEPS;
                px[idx] = Ease.catmullRom(kx[a], kx[b], kx[c], kx[d], t);
                py[idx] = Ease.catmullRom(ky[a], ky[b], ky[c], ky[d], t);
                pz[idx] = Ease.catmullRom(kz[a], kz[b], kz[c], kz[d], t);
                yaw[idx] = Ease.catmullRom(kyaw[a], kyaw[b], kyaw[c], kyaw[d], t);
                pitch[idx] = Ease.catmullRom(kpitch[a], kpitch[b], kpitch[c], kpitch[d], t);
                idx++;
            }
        }
        px[idx] = kx[n - 1];
        py[idx] = ky[n - 1];
        pz[idx] = kz[n - 1];
        yaw[idx] = kyaw[n - 1];
        pitch[idx] = kpitch[n - 1];

        len[0] = 0;
        for (int i = 1; i < count; i++) {
            len[i] = len[i - 1] + Math.sqrt(sq(px[i] - px[i - 1]) + sq(py[i] - py[i - 1]) + sq(pz[i] - pz[i - 1]));
        }
        total = len[count - 1];
    }

    private static double sq(double v) {
        return v * v;
    }

    /** Lengte van de lijn in blokken. */
    double length() {
        return total;
    }

    @Override
    public Pose at(double u) {
        if (total <= 1e-9) return pose(0, 0, 0);
        double d = Ease.trapezoid(u, ease) * total;
        int lo = 0;
        int hi = len.length - 1;
        while (hi - lo > 1) {
            int mid = (lo + hi) >>> 1;
            if (len[mid] <= d) lo = mid;
            else hi = mid;
        }
        double seg = len[hi] - len[lo];
        double f = seg <= 1e-9 ? 0 : (d - len[lo]) / seg;
        return pose(lo, hi, f);
    }

    private Pose pose(int lo, int hi, double f) {
        double x = Ease.lerp(px[lo], px[hi], f);
        double y = Ease.lerp(py[lo], py[hi], f);
        double z = Ease.lerp(pz[lo], pz[hi], f);
        double yw = Ease.lerp(yaw[lo], yaw[hi], f);
        double pt = Ease.lerp(pitch[lo], pitch[hi], f);
        pt = Math.max(-89.0, Math.min(89.0, pt));
        return new Pose(x, y, z, Ease.wrap(yw), (float) pt);
    }
}

package nl.rickey.intro;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/** SmpIntro: cinematische intro met vloeiende camerashots, titel en muziek. */
public final class IntroPlugin extends JavaPlugin {

    private PackManager packs;
    private ShotLibrary shots;
    private ChunkPreloader preloader;
    private IntroManager intro;
    private Recorder recorder;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        packs = new PackManager(this);
        shots = new ShotLibrary(this);
        preloader = new ChunkPreloader(this);
        intro = new IntroManager(this);
        recorder = new Recorder(this);
        packs.start();

        getServer().getPluginManager().registerEvents(new IntroListener(this), this);
        IntroCommand command = new IntroCommand(this);
        PluginCommand intro = getCommand("intro");
        if (intro != null) {
            intro.setExecutor(command);
            intro.setTabCompleter(command);
        }
        getLogger().info("SmpIntro " + getPluginMeta().getVersion() + " is klaar. Gebruik /intro help.");
    }

    @Override
    public void onDisable() {
        if (recorder != null) recorder.shutdown();
        if (intro != null) intro.shutdown();
        if (preloader != null) preloader.shutdown();
        if (packs != null) packs.stop();
    }

    /** Herlaadt config.yml, de opgenomen shots en de pack-instellingen. */
    void reload() {
        reloadConfig();
        shots.reload();
        packs.reload();
    }

    PackManager packs() {
        return packs;
    }

    ShotLibrary shots() {
        return shots;
    }

    ChunkPreloader preloader() {
        return preloader;
    }

    IntroManager intro() {
        return intro;
    }

    Recorder recorder() {
        return recorder;
    }
}

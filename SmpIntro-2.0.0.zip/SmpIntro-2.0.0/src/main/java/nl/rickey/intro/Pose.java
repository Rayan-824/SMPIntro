package nl.rickey.intro;

/** Positie en kijkrichting van de camera (yaw/pitch zoals in Minecraft: yaw 0 = +Z, 90 = -X). */
record Pose(double x, double y, double z, float yaw, float pitch) {

    /** Pose op (x, y, z) die naar (tx, ty, tz) kijkt. */
    static Pose lookAt(double x, double y, double z, double tx, double ty, double tz) {
        double dx = tx - x;
        double dy = ty - y;
        double dz = tz - z;
        double flat = Math.hypot(dx, dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, flat));
        return new Pose(x, y, z, yaw, pitch);
    }
}

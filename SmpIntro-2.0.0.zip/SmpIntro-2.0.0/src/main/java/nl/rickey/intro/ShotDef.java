package nl.rickey.intro;

import org.bukkit.World;

import java.util.Set;

/** Beschrijving van één shot: in welke wereld, welke chunks nodig zijn en hoe de camerabeweging eruitziet. */
interface ShotDef {

    String id();

    /** De wereld van deze shot, of null als die niet bestaat. */
    World world();

    /** Chunks die geladen moeten zijn voordat de shot soepel kan draaien (gepakt met {@link Terrain#key}). */
    Set<Long> chunks(int margin);

    /** Bouwt de camerabeweging. Alleen aanroepen nadat de chunks geladen zijn (hoogtes komen uit de wereld). */
    CameraPath build();

    /** Null als de shot bruikbaar is, anders de reden waarom niet. */
    default String check(CameraPath path) {
        return Terrain.checkClear(world(), path, 48);
    }

    /** Korte omschrijving voor /intro shots. */
    String describe();
}

package nl.rickey.intro;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.WeatherType;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * De intro voor één speler. De speler gaat in spectator-modus en kijkt door een onzichtbare camera-entiteit
 * die elke tick langs het pad wordt verplaatst. De tijd loopt op de klok vanaf het startsein van de muziek,
 * zodat de shots altijd bij de muziek blijven passen, ook als een wereldwissel even duurt.
 */
final class IntroSession {

    enum End {FINISHED, SKIPPED, QUIT, SHUTDOWN, ERROR}

    private enum State {PREPARING, RUNNING, ENDED}

    private static final class Segment {
        final String shotId;
        final World world;
        final CameraPath path;
        final Long time;
        final String caption;
        final double start;
        double end;

        Segment(String shotId, World world, CameraPath path, Long time, String caption, double start, double end) {
            this.shotId = shotId;
            this.world = world;
            this.path = path;
            this.time = time;
            this.caption = caption;
            this.start = start;
            this.end = end;
        }
    }

    private record Cue(double at, String sound, float volume) {
    }

    private final IntroPlugin plugin;
    private final IntroManager manager;
    private final Player player;
    private final List<SequenceEntry> entries;
    private final boolean full;

    private State state = State.PREPARING;
    private final List<Segment> segments = new ArrayList<>();
    private final List<Cue> cues = new ArrayList<>();
    private final Set<Integer> firedCues = new HashSet<>();
    private ChunkPreloader.Job job;
    private BossBar bar;
    private BukkitTask task;

    private GameMode originalMode;
    private Location originalLocation;
    private long prepareStart;
    private long showStart;
    private double totalSeconds;
    private int currentSegment = -1;
    private int bindTicks;
    private boolean bound;
    private boolean titleShown;
    private boolean hintShown;
    private ItemDisplay camera;
    private String musicSound;
    private boolean musicStarted;

    IntroSession(IntroPlugin plugin, IntroManager manager, Player player, List<SequenceEntry> entries, boolean full) {
        this.plugin = plugin;
        this.manager = manager;
        this.player = player;
        this.entries = entries;
        this.full = full;
    }

    Player player() {
        return player;
    }

    // ------------------------------------------------------------ voorbereiden

    void begin() {
        FileConfiguration c = plugin.getConfig();
        originalMode = player.getGameMode();
        originalLocation = player.getLocation().clone();
        manager.saveRestore(player, originalMode, originalLocation);
        player.setGameMode(GameMode.SPECTATOR);
        player.clearTitle();

        int margin = Math.max(1, c.getInt("prepare.margin-chunks", 3));
        Map<World, Set<Long>> chunks = new HashMap<>();
        for (SequenceEntry e : entries) {
            ShotDef def = plugin.shots().find(e.shot());
            if ((def == null || def.world() == null) && e.fallback() != null) def = plugin.shots().find(e.fallback());
            if (def == null || def.world() == null) continue;
            chunks.computeIfAbsent(def.world(), w -> new HashSet<>()).addAll(def.chunks(margin));
        }
        job = plugin.preloader().load(chunks);

        bar = BossBar.bossBar(Msg.mm("<gold>Intro wordt voorbereid…"), 0f, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);
        player.showBossBar(bar);
        prepareStart = System.nanoTime();
        if (full) plugin.packs().ensure(player);

        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    private void prepareTick() {
        FileConfiguration c = plugin.getConfig();
        double waited = (System.nanoTime() - prepareStart) / 1e9;
        double progress = job.progress();
        bar.progress((float) Math.max(0, Math.min(1, progress)));
        bar.name(Msg.mm("<gold>Intro wordt voorbereid… <white>" + Math.round(progress * 100) + "%"));

        // De pack opnieuw proberen te sturen zodra de SHA-1 bekend is (doet niets als hij al verstuurd is)
        if (full) plugin.packs().ensure(player);

        boolean chunksReady = job.isDone() || waited > c.getDouble("prepare.max-seconds", 120);
        boolean packReady = !full || plugin.packs().isSettled(player)
                || waited > c.getDouble("pack.wait-seconds", 25);
        if (chunksReady && packReady) startShow();
    }

    // ------------------------------------------------------------ voorstelling

    private void startShow() {
        FileConfiguration c = plugin.getConfig();
        player.hideBossBar(bar);
        buildSegments();
        if (segments.isEmpty()) {
            plugin.getLogger().warning("Geen enkele shot is bruikbaar; de intro wordt gestopt.");
            Msg.send(player, "<red>Er is geen bruikbare shot. <gray>Kijk in de console of gebruik <white>/intro shots</white>.");
            end(End.ERROR);
            return;
        }
        totalSeconds = segments.get(segments.size() - 1).end;

        if (full) {
            for (Map<?, ?> m : c.getMapList("cues")) {
                Object at = m.get("at");
                Object sound = m.get("sound");
                if (!(at instanceof Number) || sound == null) continue;
                Object vol = m.get("volume");
                cues.add(new Cue(((Number) at).doubleValue(), String.valueOf(sound),
                        vol instanceof Number ? ((Number) vol).floatValue() : 1.0f));
            }
        }

        showStart = System.nanoTime();
        state = State.RUNNING;
        if (full && c.getBoolean("music.enabled", true)) {
            musicSound = c.getString("music.sound", "smpintro:music");
            float volume = (float) c.getDouble("music.volume", 1.0);
            player.playSound(Sound.sound(Key.key(musicSound), Sound.Source.MASTER, volume, 1.0f), Sound.Emitter.self());
            musicStarted = true;
        }
    }

    /** Bouwt de camerapaden (nu de chunks geladen zijn) en rekent de tijden uit. */
    private void buildSegments() {
        double cursor = 0;
        for (SequenceEntry e : entries) {
            double start = cursor;
            double end = cursor + Math.max(1.0, e.seconds());
            cursor = end;

            String caption = e.caption();
            Segment seg = tryBuild(e.shot(), e, start, end, caption);
            if (seg == null && e.fallback() != null) {
                seg = tryBuild(e.fallback(), e, start, end, null);
            }
            if (seg != null) {
                segments.add(seg);
            } else if (!segments.isEmpty()) {
                // De tijd van deze stap gaat naar de vorige shot, zodat de muziek gelijk blijft lopen
                segments.get(segments.size() - 1).end = end;
            }
        }
    }

    private Segment tryBuild(String shotId, SequenceEntry e, double start, double end, String caption) {
        ShotDef def = plugin.shots().find(shotId);
        if (def == null) {
            plugin.getLogger().warning("Shot '" + shotId + "' bestaat niet (config.yml shots of /intro rec).");
            return null;
        }
        if (def.world() == null) {
            plugin.getLogger().warning("Shot '" + shotId + "' is overgeslagen: de wereld bestaat niet op deze server.");
            return null;
        }
        try {
            CameraPath path = def.build();
            String problem = def.check(path);
            if (problem != null) {
                plugin.getLogger().warning("Shot '" + shotId + "' is overgeslagen: " + problem
                        + ". Neem zelf een route op met /intro rec " + shotId);
                return null;
            }
            return new Segment(shotId, def.world(), path, e.time(), caption, start, end);
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Shot '" + shotId + "' is overgeslagen: " + ex);
            return null;
        }
    }

    // ------------------------------------------------------------ elke tick

    private void tick() {
        if (state == State.ENDED) return;
        if (!player.isOnline()) {
            abandon();
            return;
        }
        if (state == State.PREPARING) {
            prepareTick();
            return;
        }

        double t = (System.nanoTime() - showStart) / 1e9;
        if (t >= totalSeconds) {
            end(End.FINISHED);
            return;
        }

        // De camera pas een paar ticks na het spawnen koppelen, zodat de client de entiteit al kent.
        // Verlaat de speler de camera daarna (bijvoorbeeld met sneak), dan telt dat als overslaan.
        if (camera != null) {
            bindTicks++;
            if (!bound) {
                if (bindTicks >= 2) {
                    player.setSpectatorTarget(camera);
                    bound = true;
                    bindTicks = 0;
                }
            } else if (bindTicks > 8) {
                Object target = player.getSpectatorTarget();
                if (!(target instanceof ItemDisplay) || !((ItemDisplay) target).getUniqueId().equals(camera.getUniqueId())) {
                    end(End.SKIPPED);
                    return;
                }
            }
        }

        int idx = segmentAt(t);
        if (idx != currentSegment) {
            enterSegment(idx, t);
            if (state == State.ENDED) return;
        }

        Segment s = segments.get(currentSegment);
        double u = Math.max(0, Math.min(1, (t - s.start) / Math.max(0.001, s.end - s.start)));
        Pose p = s.path.at(u);
        moveCamera(s.world, p);

        if (!hintShown && t >= 3.0) {
            hintShown = true;
            if (full) player.sendActionBar(Msg.mm("<dark_gray>Sneak (shift) om over te slaan"));
        }

        if (full) {
            for (int i = 0; i < cues.size(); i++) {
                Cue cue = cues.get(i);
                if (t >= cue.at() && firedCues.add(i)) {
                    player.playSound(Sound.sound(Key.key(cue.sound()), Sound.Source.MASTER, cue.volume(), 1.0f),
                            Sound.Emitter.self());
                }
            }
            if (!titleShown && t >= plugin.getConfig().getDouble("title.at-seconds", 128)) {
                titleShown = true;
                showTitle();
            }
        }
    }

    private int segmentAt(double t) {
        for (int i = 0; i < segments.size(); i++) {
            if (t < segments.get(i).end) return i;
        }
        return segments.size() - 1;
    }

    private void enterSegment(int idx, double t) {
        currentSegment = idx;
        Segment s = segments.get(idx);
        double u = Math.max(0, Math.min(1, (t - s.start) / Math.max(0.001, s.end - s.start)));
        Pose p = s.path.at(u);

        // Nieuwe camera op de beginpositie: een strakke "cut" zonder doorschuiven
        removeCamera();
        try {
            player.setSpectatorTarget(null);
            bound = false;
            bindTicks = 0;
            Location at = new Location(s.world, p.x(), p.y(), p.z(), p.yaw(), p.pitch());
            player.teleport(at);
            camera = s.world.spawn(at, ItemDisplay.class, d -> {
                d.setPersistent(false);
                d.setInvulnerable(true);
                d.setGravity(false);
                d.setSilent(true);
                d.setTeleportDuration(2);
            });
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Camera plaatsen mislukt: " + ex);
            end(End.ERROR);
            return;
        }

        if (s.time != null) player.setPlayerTime(s.time, false);
        player.setPlayerWeather(WeatherType.CLEAR);
        if (idx == 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 45, 0, false, false, false));
        }
        if (s.caption != null && !s.caption.isBlank()) {
            player.sendActionBar(Msg.mm(s.caption));
        }
    }

    private void moveCamera(World world, Pose p) {
        if (camera == null || !camera.isValid()) return;
        camera.teleport(new Location(world, p.x(), p.y(), p.z(), p.yaw(), p.pitch()));
    }

    private void showTitle() {
        FileConfiguration c = plugin.getConfig();
        Component main = Msg.mm(c.getString("title.main", "<bold><gradient:#ff5a5a:#8b0000>HARDCORE SMP 2</gradient></bold>"));
        Component sub = Msg.mm(c.getString("title.sub", ""));
        Title.Times times = Title.Times.times(
                Duration.ofMillis((long) (c.getDouble("title.fade-in", 1.5) * 1000)),
                Duration.ofMillis((long) (c.getDouble("title.stay", 9.0) * 1000)),
                Duration.ofMillis((long) (c.getDouble("title.fade-out", 3.0) * 1000)));
        player.showTitle(Title.title(main, sub, times));
        String sound = c.getString("title.sound", "");
        if (sound != null && !sound.isBlank()) {
            player.playSound(player.getLocation(), sound, SoundCategory.MASTER, 1.0f, 1.0f);
        }
    }

    // ------------------------------------------------------------ opruimen

    private void removeCamera() {
        if (camera != null) {
            camera.remove();
            camera = null;
        }
    }

    /** Stopt de intro en zet de speler terug waar hij was. */
    void end(End reason) {
        if (state == State.ENDED) return;
        state = State.ENDED;
        if (task != null) task.cancel();
        if (bar != null) player.hideBossBar(bar);
        plugin.preloader().release(job);
        removeCamera();

        try {
            player.setSpectatorTarget(null);
        } catch (RuntimeException ignored) {
            // speler had de camera al verlaten
        }
        if (musicStarted && musicSound != null) {
            player.stopSound(musicSound, SoundCategory.MASTER);
        }
        player.clearTitle();
        player.resetPlayerTime();
        player.resetPlayerWeather();
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        if (originalLocation != null && originalLocation.getWorld() != null) {
            player.teleport(originalLocation);
        }
        if (originalMode != null) player.setGameMode(originalMode);
        if (reason == End.FINISHED || reason == End.SKIPPED) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false, false));
        }
        boolean completed = reason == End.FINISHED || reason == End.SKIPPED;
        manager.finished(this, completed && full, true);
    }

    /**
     * De speler is offline gegaan zonder dat we hem konden terugzetten (bijvoorbeeld een crash). We ruimen alleen
     * op; het herstel staat in restore.yml en gebeurt bij de volgende join.
     */
    private void abandon() {
        if (state == State.ENDED) return;
        state = State.ENDED;
        if (task != null) task.cancel();
        plugin.preloader().release(job);
        removeCamera();
        manager.finished(this, false, false);
    }
}

package nl.rickey.intro;

import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Rechte vlucht over het landschap; de hoogte volgt het terrein. */
final class FlyoverShot implements ShotDef {

    private static final double SPACING = 8.0;

    private final String id;
    private final World world;
    private final double cx;
    private final double cz;
    private final double heading;
    private final double length;
    private final boolean ground;
    private final double height;
    private final double pitch;
    private final double sway;
    private final double ease;

    private FlyoverShot(String id, World world, double cx, double cz, double heading, double length,
                        boolean ground, double height, double pitch, double sway, double ease) {
        this.id = id;
        this.world = world;
        this.cx = cx;
        this.cz = cz;
        this.heading = heading;
        this.length = length;
        this.ground = ground;
        this.height = height;
        this.pitch = pitch;
        this.sway = sway;
        this.ease = ease;
    }

    static FlyoverShot from(String id, World world, ConfigurationSection c) {
        double[] center = world == null ? new double[]{0, 0} : ShotLibrary.center(c.getString("center"), world);
        boolean ground = !"absolute".equalsIgnoreCase(c.getString("y-mode", "ground"));
        return new FlyoverShot(id, world, center[0], center[1],
                c.getDouble("heading", 270), c.getDouble("length", 300),
                ground, c.getDouble("clearance", c.getDouble("height", 22)),
                c.getDouble("pitch", 12), c.getDouble("sway", 6), c.getDouble("ease", 0.12));
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public World world() {
        return world;
    }

    private double dirX() {
        return -Math.sin(Math.toRadians(heading));
    }

    private double dirZ() {
        return Math.cos(Math.toRadians(heading));
    }

    @Override
    public Set<Long> chunks(int margin) {
        Set<Long> out = new HashSet<>();
        if (world == null) return out;
        int steps = (int) Math.ceil(length / SPACING);
        for (int i = 0; i <= steps; i++) {
            double d = -length / 2 + i * SPACING;
            Terrain.addAround(out, cx + dirX() * d, cz + dirZ() * d, margin);
        }
        return out;
    }

    @Override
    public CameraPath build() {
        int n = (int) Math.ceil(length / SPACING) + 1;
        double[] terrain = new double[n];
        double[] px = new double[n];
        double[] pz = new double[n];
        for (int i = 0; i < n; i++) {
            double d = -length / 2 + i * SPACING;
            px[i] = cx + dirX() * d;
            pz[i] = cz + dirZ() * d;
            terrain[i] = ground ? Terrain.ground(world, px[i], pz[i]) : 0;
        }
        double[] y = new double[n];
        if (ground) {
            // Eerst de hoogste top in de buurt nemen en daarna afvlakken, zodat de camera niet langs bergen schuurt
            double[] peak = new double[n];
            for (int i = 0; i < n; i++) {
                double m = terrain[i];
                for (int k = Math.max(0, i - 3); k <= Math.min(n - 1, i + 3); k++) m = Math.max(m, terrain[k]);
                peak[i] = m;
            }
            for (int i = 0; i < n; i++) {
                double sum = 0;
                int cnt = 0;
                for (int k = Math.max(0, i - 3); k <= Math.min(n - 1, i + 3); k++) {
                    sum += peak[k];
                    cnt++;
                }
                y[i] = Math.max(sum / cnt, terrain[i]) + height;
            }
        } else {
            for (int i = 0; i < n; i++) y[i] = height;
        }
        List<Pose> keys = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            double f = n <= 1 ? 0 : i / (double) (n - 1);
            double swing = Math.sin(f * Math.PI * 2 * 1.25);
            keys.add(new Pose(px[i], y[i], pz[i], (float) (heading + sway * swing),
                    (float) (pitch + 2.0 * Math.sin(f * Math.PI * 2))));
        }
        return new SplinePath(keys, ease);
    }

    @Override
    public String describe() {
        return String.format(Locale.ROOT, "rechte vlucht van %.0f blokken (richting %.0f)", length, heading);
    }
}

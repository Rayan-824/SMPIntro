package nl.rickey.intro;

import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Cirkelvlucht rond een punt, bijvoorbeeld rond de spawn. */
final class OrbitShot implements ShotDef {

    private final String id;
    private final World world;
    private final double cx;
    private final double cz;
    private final boolean ground;
    private final double r0;
    private final double r1;
    private final double h0;
    private final double h1;
    private final double lookHeight;
    private final double startDeg;
    private final double sweepDeg;
    private final double ease;
    private final boolean validate;

    private OrbitShot(String id, World world, double cx, double cz, boolean ground, double r0, double r1,
                      double h0, double h1, double lookHeight, double startDeg, double sweepDeg,
                      double ease, boolean validate) {
        this.id = id;
        this.world = world;
        this.cx = cx;
        this.cz = cz;
        this.ground = ground;
        this.r0 = r0;
        this.r1 = r1;
        this.h0 = h0;
        this.h1 = h1;
        this.lookHeight = lookHeight;
        this.startDeg = startDeg;
        this.sweepDeg = sweepDeg;
        this.ease = ease;
        this.validate = validate;
    }

    static OrbitShot from(String id, World world, ConfigurationSection c) {
        double[] center = world == null ? new double[]{0, 0} : ShotLibrary.center(c.getString("center"), world);
        boolean ground = !"absolute".equalsIgnoreCase(c.getString("y-mode", "ground"));
        double r0 = c.getDouble("radius", 45);
        double h0 = c.getDouble("height", 20);
        return new OrbitShot(id, world, center[0], center[1], ground,
                r0, c.getDouble("radius-end", r0),
                h0, c.getDouble("height-end", h0),
                c.getDouble("look-height", 4),
                c.getDouble("start-angle", 0), c.getDouble("sweep", 90),
                c.getDouble("ease", 0.3),
                c.getBoolean("validate", !ground));
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public World world() {
        return world;
    }

    @Override
    public Set<Long> chunks(int margin) {
        Set<Long> out = new HashSet<>();
        if (world != null) Terrain.addDisk(out, cx, cz, Math.max(r0, r1) + margin * 16.0);
        return out;
    }

    @Override
    public CameraPath build() {
        double base = ground ? Terrain.ground(world, cx, cz) : 0;
        double y0 = base + h0;
        double y1 = base + h1;
        double lookY = base + lookHeight;
        if (ground) {
            // Boven bergen en bomen langs de cirkel blijven
            double need = Double.NEGATIVE_INFINITY;
            for (int k = 0; k <= 16; k++) {
                double s = k / 16.0;
                double a = Math.toRadians(startDeg + sweepDeg * s);
                double r = Ease.lerp(r0, r1, s);
                need = Math.max(need, Terrain.ground(world, cx + r * Math.cos(a), cz + r * Math.sin(a)) + 10);
            }
            y0 = Math.max(y0, need);
            y1 = Math.max(y1, need);
        }
        return new OrbitPath(cx, cz, lookY, r0, r1, y0, y1, startDeg, sweepDeg, ease);
    }

    @Override
    public String check(CameraPath path) {
        return validate || ground ? Terrain.checkClear(world, path, 48) : null;
    }

    @Override
    public String describe() {
        return String.format(Locale.ROOT, "cirkel rond %.0f, %.0f (straal %.0f)", cx, cz, Math.max(r0, r1));
    }
}

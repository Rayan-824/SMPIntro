package nl.rickey.intro;

/** Hulpfuncties voor soepele bewegingen. */
final class Ease {

    private Ease() {
    }

    static double clamp01(double v) {
        return v < 0 ? 0 : Math.min(v, 1);
    }

    static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    /**
     * Constante snelheid met zacht optrekken en afremmen. e is het deel van de tijd (0 tot 0,5) dat aan
     * het begin en einde wordt gebruikt om te versnellen of af te remmen. e = 0 geeft een rechte lijn.
     */
    static double trapezoid(double u, double e) {
        u = clamp01(u);
        if (e <= 0.0001) return u;
        e = Math.min(0.5, e);
        double vmax = 1.0 / (1.0 - e);
        if (u < e) return vmax * u * u / (2 * e);
        if (u > 1 - e) {
            double r = 1 - u;
            return 1 - vmax * r * r / (2 * e);
        }
        return vmax * (e / 2 + (u - e));
    }

    /** Hoek in graden naar het bereik [-180, 180). */
    static float wrap(double degrees) {
        double d = degrees % 360.0;
        if (d >= 180.0) d -= 360.0;
        if (d < -180.0) d += 360.0;
        return (float) d;
    }

    /** Catmull-Rom tussen p1 en p2 (t van 0 tot 1). */
    static double catmullRom(double p0, double p1, double p2, double p3, double t) {
        double t2 = t * t;
        double t3 = t2 * t;
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
                + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
    }
}

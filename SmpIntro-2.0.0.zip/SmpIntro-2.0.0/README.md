# SmpIntro 2.0.0

Cinematische intro voor de Hardcore SMP 2: vloeiende camerashots door de Overworld, de Nether en The End, de titel
**HARDCORE SMP 2** en jouw muziek eronder (Aria Math x Cinematic Orchestra).

## Installeren

1. Verwijder de oude SmpIntro: `plugins/SmpIntro.jar` én de map `plugins/SmpIntro/` (anders blijft de oude config staan).
2. Bouw de plugin in een nieuwe, lege map (IntelliJ: Maven > Lifecycle > package). Zet `target/SmpIntro.jar` in `plugins/`.
3. Start de server. In `plugins/SmpIntro/` staan nu `config.yml` en **`SmpIntroPack.zip`** (de resource pack met de muziek).

## De muziek (resource pack) werkend krijgen

Spelers hebben de pack nodig om de muziek te horen; zonder pack werkt de intro wel, maar stil.
De pack moet via een **directe downloadlink** bereikbaar zijn.

**Optie A: GitHub (aanbevolen)**
1. Maak een publieke repository en upload `SmpIntroPack.zip` (Add file > Upload files).
2. Klik op het bestand en kies **Raw** (of Download raw file). Kopieer die URL: `https://raw.githubusercontent.com/<jij>/<repo>/main/SmpIntroPack.zip`.
   Gebruik dus niet de `github.com/.../blob/...`-link: dat is een webpagina.
3. Zet de URL in `pack.url` in `config.yml` en doe `/intro reload`.
4. Doe `/intro pack test`. Je ziet nu of de link werkt en wat de SHA-1 is. Bij een fout staat er precies wat er mis is.

**Optie B: eigen poort**: zet `pack.server.enabled: true`, kies een poort die je bij je host hebt vrijgemaakt en vul `pack.server.address` in.

## Gebruik

| Commando | Wat het doet |
| --- | --- |
| `/intro play [speler/all]` | Hele intro afspelen |
| `/intro skip` of sneak (shift) | Overslaan |
| `/intro preview <shot> [seconden]` | Eén shot bekijken |
| `/intro rec <naam>` ... `/intro rec stop` | Je eigen vlucht opnemen als shot |
| `/intro shots` | Volgorde en status van alle shots |
| `/intro prepare` | Chunks vooraf genereren (aanrader vóór de eerste keer) |
| `/intro pack test` | Pack-link controleren |
| `/intro reset <speler/all>` | Intro opnieuw laten afspelen bij de volgende join |

Automatisch afspelen staat standaard uit, zodat je eerst rustig kunt testen. Zet `auto-play.enabled: true` in config.yml zodra alles goed is: dan ziet elke speler de intro één keer bij het joinen.

## Eigen shots opnemen (voor de allermooiste beelden)

De automatische shots zijn cirkels en vluchten rond de spawn. Het mooist wordt het met routes die jij zelf vliegt:

1. Ga in creative of spectator op de plek waar je wilt beginnen.
2. `/intro rec nether-calm` (de naam moet in `sequence` staan, bijvoorbeeld `dawn`, `flyover`, `nether-calm`, `end-high`).
3. Vlieg rustig je route en kijk zoals je het in beeld wilt. Kleine schokjes worden automatisch gladgestreken.
4. `/intro rec stop`, daarna `/intro preview nether-calm`.

Een opname met dezelfde naam als een shot in `sequence` vervangt de automatische versie. De duur stel je in bij `seconds`.

## Muziek en timing

De muziek duurt ongeveer 177 seconden: rustig begin tot 10 s, drop op 10 s, breakdown 58-68 s, tweede drop op 68 s,
climax rond 128 s en uitlopen tot 172 s. De standaard `sequence` (172 s) is hierop afgestemd; de titel verschijnt op
`title.at-seconds: 128`. De tijd loopt op de klok vanaf het startsein van de muziek, dus de shots blijven bij de muziek,
ook als een wereldwissel even duurt.

## Voice-over of ander geluid toevoegen

Zet een `.ogg`-bestand in de pack als `assets/smpintro/sounds/voice.ogg` en voeg dit toe aan `assets/smpintro/sounds.json`:
`"voice": {"sounds": [{"name": "smpintro:voice", "stream": true}]}`. Plan het daarna in bij `cues` in config.yml, bijvoorbeeld
`- {at: 12.0, sound: "smpintro:voice"}`. Upload de pack opnieuw (de SHA-1 wordt automatisch opnieuw uitgerekend).

## Veiligheid

Tijdens de intro staat een speler in spectator-modus en kan niets overkomen. De oorspronkelijke positie en gamemode staan
in `restore.yml`; na een crash of herstart wordt de speler bij de volgende join automatisch teruggezet.
